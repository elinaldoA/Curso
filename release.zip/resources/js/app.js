/* Importar o arquivo bootstrap */
import './bootstrap';

/* Importar o JS personalizado */
import './custom';