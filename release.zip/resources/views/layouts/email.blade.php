<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Gestor de contas</title>
</head>

<body>

    <div style="padding: 10px;">

        @yield('content')

    </div>

</body>

</html>
